from PIL import Image
from numpy import *
import matplotlib.pyplot as plt
import scipy.misc

w = "/home/pbso/Tensorflow/adesh/output_W/sample19.jpg"
mean = "/home/pbso/Tensorflow/adesh/mean/296.png"
xn="/home/pbso/Tensorflow/adesh/output_xn/sample19.jpg"

W = asarray(Image.open(w)).astype(float32)
t_mean = asarray(Image.open(mean)).astype(float32)
Xn = asarray(Image.open(xn)).astype(float32)
t_mean = matrix.transpose(t_mean)

# print W.shape
# print t_mean.shape
# print Xn.shape

print W

temp =  dot(W,Xn)

temp = matrix.transpose(temp)


for i in xrange(temp.shape[0]):
    for j in xrange(len(t_mean)):
        # print i,j
        temp[i][j] += t_mean[j]

# print temp.shape
plt.imshow(temp,aspect="auto")
plt.show()
scipy.misc.imsave('20paper.jpg', temp)